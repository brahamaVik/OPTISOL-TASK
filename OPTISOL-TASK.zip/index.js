export {default} from "./main.js";
